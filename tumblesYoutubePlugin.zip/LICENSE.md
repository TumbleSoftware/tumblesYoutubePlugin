tumblesYoutubePlugin is published under the GNU General Public License

http://www.gnu.org/copyleft/gpl.html
