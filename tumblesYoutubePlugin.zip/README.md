tumblesYoutubePlugin
====================

A jQuery plugin which searches youtube data and displays the results using HTML templates loaded by AJAX. 
